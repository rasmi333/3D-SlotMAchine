package com.examples.activityanimation;

import android.media.SoundPool;

public class Assets {

    static SoundPool sp;
    static int soundeffect;
}
