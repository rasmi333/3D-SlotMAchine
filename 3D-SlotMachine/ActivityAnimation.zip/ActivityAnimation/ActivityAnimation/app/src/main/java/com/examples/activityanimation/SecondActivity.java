package com.examples.activityanimation;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


    }
    public void onClick(View v) {
        // currently does nothing, use the backbutton to transition back to the first Activity
    }
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        int action = event.getAction();
        if (action == MotionEvent.ACTION_UP) {
            Intent intent = new Intent();
            intent.setClass(SecondActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.left_in, R.anim.right_out);
            Assets.sp.play(Assets.soundeffect, 1, 1, 0, 0, 1);
            //finish(); // use this to close this Activity permanently
        }
        return true; // to indicate we have handled this event
    }

}

